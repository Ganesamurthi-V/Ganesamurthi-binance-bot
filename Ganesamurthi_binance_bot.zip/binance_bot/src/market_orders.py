import argparse
import logging

from client import BinanceFuturesClient
from validator import validate_symbol, validate_side, validate_quantity
from logger import setup_logger


def print_summary(symbol, side, quantity):
    print("\n=== Order Request Summary ===")
    print(f"Symbol: {symbol}")
    print(f"Side: {side}")
    print("Type: MARKET")
    print(f"Quantity: {quantity}")


def main():
    setup_logger()

    parser = argparse.ArgumentParser(
        description="Place a MARKET order on Binance Futures Testnet"
    )
    parser.add_argument("symbol", help="Trading symbol e.g. BTCUSDT")
    parser.add_argument("side", help="BUY or SELL")
    parser.add_argument("quantity", type=float, help="Order quantity")

    args = parser.parse_args()

    try:
        symbol = validate_symbol(args.symbol)
        side = validate_side(args.side)
        quantity = validate_quantity(args.quantity)

        client = BinanceFuturesClient()

        logging.info(f"Placing MARKET order | {symbol} | {side} | {quantity}")

        client.set_margin_type(symbol)
        client.set_leverage(symbol, leverage=10)

        print_summary(symbol, side, quantity)

        response = client.place_market_order(
            symbol=symbol,
            side=side,
            quantity=quantity
        )

        logging.info(f"Market order response: {response}")


    except Exception as e:
        logging.error(f"Market order error: {e}")
        print(f"\nOrder failed: {e}")


if __name__ == "__main__":
    main()
