import argparse
import logging

from client import BinanceFuturesClient
from validator import (
    validate_symbol,
    validate_side,
    validate_quantity,
    validate_price
)
from logger import setup_logger


def print_summary(symbol, side, quantity, price):
    print("\n=== Order Request Summary ===")
    print(f"Symbol: {symbol}")
    print(f"Side: {side}")
    print("Type: LIMIT")
    print(f"Quantity: {quantity}")
    print(f"Price: {price}")


def print_response(response):
    print("\n=== Order Response ===")
    print(f"Order ID: {response.get('orderId')}")
    print(f"Status: {response.get('status')}")
    print(f"Executed Qty: {response.get('executedQty')}")
    print(f"Avg Price: {response.get('avgPrice', 'N/A')}")

    if response.get("status") in {"NEW", "FILLED", "PARTIALLY_FILLED"}:
        print("\n Order placed successfully")
    else:
        print("\nOrder placed but status is unusual")


def main():
    setup_logger()

    parser = argparse.ArgumentParser(
        description="Place a LIMIT order on Binance Futures Testnet"
    )
    parser.add_argument("symbol", help="Trading symbol e.g. BTCUSDT")
    parser.add_argument("side", help="BUY or SELL")
    parser.add_argument("quantity", type=float, help="Order quantity")
    parser.add_argument("price", type=float, help="Limit price")

    args = parser.parse_args()

    try:
        symbol = validate_symbol(args.symbol)
        side = validate_side(args.side)
        quantity = validate_quantity(args.quantity)
        price = validate_price(args.price)

        client = BinanceFuturesClient()

        client.set_margin_type(symbol)
        client.set_leverage(symbol, leverage=10)

        logging.info(
            f"Placing LIMIT order | {symbol} | {side} | "
            f"qty={quantity} | price={price}"
        )

        print_summary(symbol, side, quantity, price)

        response = client.place_limit_order(
            symbol=symbol,
            side=side,
            quantity=quantity,
            price=price
        )

        logging.info(f"Limit order response: {response}")

        print_response(response)

    except Exception as e:
        logging.error(f"Limit order error: {e}")
        print(f"\n Order failed: {e}")


if __name__ == "__main__":
    main()
