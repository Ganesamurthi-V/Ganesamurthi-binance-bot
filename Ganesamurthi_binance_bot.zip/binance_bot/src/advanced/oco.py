import sys
import os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

import argparse
import logging

from client import BinanceFuturesClient
from validator import (
    validate_symbol,
    validate_side,
    validate_quantity,
    validate_price
)
from logger import setup_logger


def main():
    setup_logger()

    parser = argparse.ArgumentParser(
        description="Place Futures TP + SL (OCO-style exit)"
    )

    parser.add_argument("symbol")
    parser.add_argument("side")
    parser.add_argument("quantity", type=float)
    parser.add_argument("take_profit_price", type=float)
    parser.add_argument("stop_price", type=float)
    parser.add_argument("stop_limit_price", type=float)

    args = parser.parse_args()

    try:
        symbol = validate_symbol(args.symbol)
        side = validate_side(args.side)
        quantity = validate_quantity(args.quantity)

        tp_price = validate_price(args.take_profit_price)
        stop_price = validate_price(args.stop_price)
        stop_limit_price = validate_price(args.stop_limit_price)

        if stop_limit_price == stop_price:
            raise ValueError("Stop-limit price must differ from stop trigger")

        client = BinanceFuturesClient()
        client.set_margin_type(symbol)
        client.set_leverage(symbol, leverage=10)

        logging.info(
            f"OCO exit | {symbol} | {side} | qty={quantity} | "
            f"TP={tp_price} | SL={stop_price}->{stop_limit_price}"
        )

        # TAKE PROFIT
        tp_response = client.client.futures_create_order(
            symbol=symbol,
            side=side,
            type="TAKE_PROFIT_MARKET",
            stopPrice=tp_price,
            quantity=quantity,
            reduceOnly=True,
            workingType="MARK_PRICE"
        )

        tp_id = tp_response.get("orderId")
        logging.info(f"TP placed | id={tp_id}")

        # STOP LOSS
        sl_response = client.client.futures_create_order(
            symbol=symbol,
            side=side,
            type="STOP",
            stopPrice=stop_price,
            price=stop_limit_price,
            quantity=quantity,
            timeInForce="GTC",
            reduceOnly=True,
            workingType="MARK_PRICE"
        )

        sl_id = sl_response.get("orderId")
        logging.info(f"SL placed | id={sl_id}")

        logging.info("OCO exit submitted successfully")

    except Exception as e:
        logging.error(f"OCO error: {e}")
        print(f"Error: {e}")


if __name__ == "__main__":
    main()
