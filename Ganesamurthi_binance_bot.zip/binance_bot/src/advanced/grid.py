# src/advanced/grid.py

import sys
import os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

import argparse
import logging

from client import BinanceFuturesClient
from validator import validate_symbol, validate_quantity, validate_price
from logger import setup_logger


def round_to_tick(price, tick_size=0.1):
    return round(price / tick_size) * tick_size


def main():
    setup_logger()

    parser = argparse.ArgumentParser(description="Grid Trading Strategy")

    # new CLI style
    parser.add_argument("symbol")

    parser.add_argument("--lower", required=True, type=float)
    parser.add_argument("--upper", required=True, type=float)
    parser.add_argument("--levels", required=True, type=int)
    parser.add_argument("--qty-per-order", required=True, type=float)

    args = parser.parse_args()

    try:
        symbol = validate_symbol(args.symbol)
        lower = validate_price(args.lower)
        upper = validate_price(args.upper)
        levels = args.levels
        qty = validate_quantity(args.qty_per_order)

        if upper <= lower:
            raise ValueError("Upper price must be greater than lower price")

        if levels < 2:
            raise ValueError("Grid levels must be at least 2")

        grid_spacing = (upper - lower) / (levels - 1)

        client = BinanceFuturesClient()
        client.set_margin_type(symbol)
        client.set_leverage(symbol, leverage=10)

        logging.info(
            f"Grid start | {symbol} | range=({lower}-{upper}) | "
            f"levels={levels} | qty={qty}"
        )

        orders_placed = 0
        mid_price = (lower + upper) / 2

        for i in range(levels):
            price = round_to_tick(lower + i * grid_spacing)
            side = "BUY" if price < mid_price else "SELL"

            try:
                response = client.place_limit_order(
                    symbol=symbol,
                    side=side,
                    quantity=qty,
                    price=price
                )

                order_id = response.get("orderId")
                logging.info(f"Grid order placed | id={order_id} | {side} @ {price}")
                orders_placed += 1

            except Exception as order_error:
                logging.error(f"Grid order failed | {side} @ {price} | {order_error}")

        logging.info(f"Grid complete | orders placed: {orders_placed}")

    except Exception as e:
        logging.error(f"Grid error: {e}")
        print("\n❌ Error:", e)


if __name__ == "__main__":
    main()
