import sys
import os
import time
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

import argparse
import logging

from client import BinanceFuturesClient
from validator import validate_symbol, validate_side, validate_quantity
from logger import setup_logger


def main():
    setup_logger()

    parser = argparse.ArgumentParser(description="TWAP execution")

    parser.add_argument("symbol")
    parser.add_argument("side")
    parser.add_argument("total_quantity", type=float)
    parser.add_argument("duration_seconds", type=int)
    parser.add_argument("interval_seconds", type=int)

    args = parser.parse_args()

    try:
        symbol = validate_symbol(args.symbol)
        side = validate_side(args.side)
        total_qty = validate_quantity(args.total_quantity)

        duration = args.duration_seconds
        interval = args.interval_seconds

        if duration <= 0 or interval <= 0:
            raise ValueError("Duration and interval must be positive")

        slices = max(1, duration // interval)
        slice_qty = total_qty / slices

        client = BinanceFuturesClient()
        client.set_margin_type(symbol)
        client.set_leverage(symbol, leverage=10)

        logging.info(
            f"TWAP start | {symbol} | {side} | "
            f"total={total_qty} | slices={slices} | interval={interval}s"
        )

        remaining = total_qty
        completed = 0

        for i in range(slices):
            qty = remaining if i == slices - 1 else round(slice_qty, 6)

            try:
                response = client.place_market_order(symbol, side, qty)

                logging.info(
                    f"Slice {i+1}/{slices} | qty={qty} | "
                    f"id={response.get('orderId')} | status={response.get('status')}"
                )

                completed += 1
                remaining = round(remaining - qty, 6)

            except Exception as err:
                logging.error(f"Slice {i+1} failed | qty={qty} | {err}")

            if i < slices - 1:
                time.sleep(interval)

        logging.info(
            f"TWAP complete | executed={completed}/{slices} | remaining={remaining}"
        )

    except Exception as e:
        logging.error(f"TWAP error: {e}")
        print(f"Error: {e}")


if __name__ == "__main__":
    main()
