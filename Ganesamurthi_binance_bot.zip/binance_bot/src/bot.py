import argparse
import logging
import time

from logger import setup_logger
from validator import (
    validate_symbol,
    validate_side,
    validate_quantity,
    validate_price,
)
from client import BinanceFuturesClient


def round_to_tick(price, tick_size=0.1):
    return round(price / tick_size) * tick_size


def main():
    setup_logger()

    parser = argparse.ArgumentParser(description="Unified Binance Futures Bot")

    parser.add_argument("symbol")
    parser.add_argument("order_type")
    parser.add_argument("side")
    parser.add_argument("quantity", type=float)

    parser.add_argument("--price", type=float)
    parser.add_argument("--stop", type=float)
    parser.add_argument("--tp", type=float)

    # TWAP settings (match standalone script)
    parser.add_argument("--duration", type=int)
    parser.add_argument("--interval", type=int)

    # grid
    parser.add_argument("--lower", type=float)
    parser.add_argument("--upper", type=float)
    parser.add_argument("--levels", type=int)

    # oco
    parser.add_argument("--tp-price", type=float)
    parser.add_argument("--sl-trigger", type=float)
    parser.add_argument("--sl-limit", type=float)

    parser.add_argument("--reduce-only", action="store_true")

    args = parser.parse_args()

    try:
        symbol = validate_symbol(args.symbol)
        side = validate_side(args.side)
        qty = validate_quantity(args.quantity)

        client = BinanceFuturesClient()
        client.set_margin_type(symbol)
        client.set_leverage(symbol, 10)

        mark = float(client.client.futures_mark_price(symbol=symbol)["markPrice"])
        t = args.order_type.upper()

        logging.info(f"Order request | {symbol} | {t} | {side} | qty={qty} | mark={mark}")

        # ---------- MARKET ----------
        if t == "MARKET":
            r = client.place_market_order(symbol, side, qty)

        # ---------- LIMIT ----------
        elif t == "LIMIT":
            price = validate_price(args.price)
            r = client.place_limit_order(symbol, side, qty, price)

        # ---------- STOP LIMIT ----------
        elif t == "STOP_LIMIT":
            stop = validate_price(args.stop)
            price = validate_price(args.price)

            if side == "SELL" and stop >= mark:
                raise ValueError("SELL stop must be BELOW market")

            if side == "BUY" and stop <= mark:
                raise ValueError("BUY stop must be ABOVE market")

            r = client.client.futures_create_order(
                symbol=symbol,
                side=side,
                type="STOP",
                quantity=qty,
                price=price,
                stopPrice=stop,
                timeInForce="GTC",
                reduceOnly=args.reduce_only,
                workingType="MARK_PRICE"
            )

        # ---------- OCO ----------
        elif t == "OCO":
            tp = validate_price(args.tp_price)
            stop = validate_price(args.sl_trigger)
            stop_limit = validate_price(args.sl_limit)

            if side == "SELL" and stop >= mark:
                raise ValueError("SELL SL must be BELOW market")

            if side == "BUY" and stop <= mark:
                raise ValueError("BUY SL must be ABOVE market")

            tp_r = client.client.futures_create_order(
                symbol=symbol,
                side=side,
                type="TAKE_PROFIT_MARKET",
                stopPrice=tp,
                quantity=qty,
                reduceOnly=True,
                workingType="MARK_PRICE"
            )

            sl_r = client.client.futures_create_order(
                symbol=symbol,
                side=side,
                type="STOP",
                stopPrice=stop,
                price=stop_limit,
                quantity=qty,
                timeInForce="GTC",
                reduceOnly=True,
                workingType="MARK_PRICE"
            )

            r = {"tp": tp_r, "sl": sl_r}

        # ---------- TWAP ----------
        elif t == "TWAP":
            duration = args.duration
            interval = args.interval

            if not duration or not interval:
                raise ValueError("TWAP requires --duration and --interval")

            if duration <= 0 or interval <= 0:
                raise ValueError("Duration/interval must be positive")

            slices = max(1, duration // interval)
            slice_qty = qty / slices

            remaining = qty
            completed = 0

            logging.info(
                f"TWAP start | slices={slices} | interval={interval}s"
            )

            for i in range(slices):
                part = remaining if i == slices - 1 else round(slice_qty, 6)

                r = client.place_market_order(symbol, side, part)

                logging.info(
                    f"Slice {i+1}/{slices} | qty={part} | "
                    f"id={r.get('orderId')}"
                )

                remaining = round(remaining - part, 6)
                completed += 1

                if i < slices - 1:
                    time.sleep(interval)

            logging.info(
                f"TWAP complete | executed={completed}/{slices} | remaining={remaining}"
            )

        # ---------- GRID ----------
        elif t == "GRID":
            lower = validate_price(args.lower)
            upper = validate_price(args.upper)
            levels = args.levels

            if upper <= lower:
                raise ValueError("Upper must be greater than lower")

            if levels < 2:
                raise ValueError("Grid levels must be >= 2")

            spacing = (upper - lower) / (levels - 1)
            mid = (lower + upper) / 2
            part_qty = qty / levels

            orders = []

            for i in range(levels):
                price = round_to_tick(lower + i * spacing)
                s = "BUY" if price < mid else "SELL"
                r = client.place_limit_order(symbol, s, part_qty, price)
                logging.info(f"Grid {s} @ {price}: {r}")
                orders.append(r)

            r = orders

        else:
            raise ValueError("Unknown order type")

        logging.info(f"Final response: {r}")

    except Exception as e:
        logging.error(str(e))
        print("\n❌ Error:", e)


if __name__ == "__main__":
    main()
