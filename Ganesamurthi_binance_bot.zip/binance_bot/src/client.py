
import logging
import os
from dotenv import load_dotenv
from binance.client import Client
from binance.exceptions import BinanceAPIException, BinanceRequestException
load_dotenv()

class BinanceFuturesClient:
    def __init__(self):
        api_key = os.getenv("BINANCE_API_KEY")
        api_secret = os.getenv("BINANCE_API_SECRET")

        if not api_key or not api_secret:
            raise RuntimeError("API keys not found in .env file")

        self.client = Client(api_key, api_secret, testnet=True)

    def place_market_order(self, symbol: str, side: str, quantity: float):
        request = {
            "symbol": symbol,
            "side": side,
            "type": "MARKET",
            "quantity": quantity,
        }

        logging.info(f"Request: {request}")

        try:
            response = self.client.futures_create_order(**request)
            logging.info(f"Response: {response}")
            return response

        except (BinanceAPIException, BinanceRequestException) as e:
            logging.error(f"API Error: {e}")
            raise
        except Exception as e:
            logging.error(f"Unexpected Error: {e}")
            raise


    def place_limit_order(self, symbol: str, side: str, quantity: float, price: float):
        request = {
            "symbol": symbol,
            "side": side,
            "type": "LIMIT",
            "timeInForce": "GTC",
            "quantity": quantity,
            "price": price,
        }

        logging.info(f"Request: {request}")

        try:
            response = self.client.futures_create_order(**request)
            logging.info(f"Response: {response}")
            return response

        except (BinanceAPIException, BinanceRequestException) as e:
            logging.error(f"API Error: {e}")
            raise
        except Exception as e:
            logging.error(f"Unexpected Error: {e}")
            raise

    def place_stop_limit_order(
        self,
        symbol: str,
        side: str,
        quantity: float,
        stop_price: float,
        price: float,
    ):
        request = {
            "symbol": symbol,
            "side": side,
            "type": "STOP",
            "timeInForce": "GTC",
            "quantity": quantity,
            "price": price,
            "stopPrice": stop_price,
        }

        logging.info(f"Request: {request}")

        try:
            response = self.client.futures_create_order(**request)
            logging.info(f"Response: {response}")
            return response

        except (BinanceAPIException, BinanceRequestException) as e:
            logging.error(f"API Error: {e}")
            raise
        except Exception as e:
            logging.error(f"Unexpected Error: {e}")
            raise

    def place_oco(
        self,
        symbol: str,
        side: str,
        quantity: float,
        take_profit_price: float,
        stop_price: float,
    ):
        logging.info(
            f"OCO Request: symbol={symbol}, side={side}, qty={quantity}, "
            f"tp={take_profit_price}, stop={stop_price}"
        )

        try:
            tp = self.client.futures_create_order(
                symbol=symbol,
                side=side,
                type="TAKE_PROFIT_MARKET",
                stopPrice=take_profit_price,
                quantity=quantity,
            )

            sl = self.client.futures_create_order(
                symbol=symbol,
                side=side,
                type="STOP_MARKET",
                stopPrice=stop_price,
                quantity=quantity,
            )

            response = {"take_profit": tp, "stop_loss": sl}

            logging.info(f"OCO Response: {response}")
            return response

        except (BinanceAPIException, BinanceRequestException) as e:
            logging.error(f"OCO API Error: {e}")
            raise
        except Exception as e:
            logging.error(f"OCO Unexpected Error: {e}")
            raise


    def set_margin_type(self, symbol: str):
        try:
            self.client.futures_change_margin_type(symbol=symbol, marginType="ISOLATED")
            logging.info(f"Margin type set to ISOLATED for {symbol}")
        except BinanceAPIException as e:
            logging.warning(f"Margin type may already be set: {e}")

    def set_leverage(self, symbol: str, leverage: int):
        try:
            self.client.futures_change_leverage(symbol=symbol, leverage=leverage)
            logging.info(f"Leverage set to {leverage}x for {symbol}")
        except BinanceAPIException as e:
            logging.error(f"Leverage error: {e}")
            raise
